# Nursery-shop-management-system

This Project is Built Using django framework .

                   This is the nursery Shop management project.
                            where 
                                  user can:-
                                                    login
                                                    logout
                                                    signup
                                                    add products to cart
                                                    checkout
                                                    contact 
                                                    track their product

                                  manager can:-
                                                    login(manager login)
                                                    see all products
                                                    add products
                                                    send status for particular order id
                                                    can see recieved order
